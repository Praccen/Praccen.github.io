use code_test_lib as ct;
use {ct::behavior::*, ct::prelude::*, ct::player};

pub struct AIShipBehavior {
    result: SensorScanResult,
}

impl AIShipBehavior {
    pub fn new() -> Self {
        Self {
            result: SensorScanResult::default(),
        }
    }
}

impl ShipBehavior for AIShipBehavior {
    fn behave(
        &mut self,
        ship: &BehaviorShipInfo,
        _game: &BehaviorGameInfo,
        _dt: f32,
        api: &mut dyn ShipBehaviorApi,
    ) {

        // Raycast directions, outwards from the ship
        let mut directions: [Vector2; SENSOR_RESOLUTION] = [Vector2::zeros(); SENSOR_RESOLUTION];
        let angle_increment = 6.28 / SENSOR_RESOLUTION as f32;
        for i in 0..SENSOR_RESOLUTION {
            directions[i].x = (i as f32 * angle_increment).cos();
            directions[i].y = (i as f32 * angle_increment).sin();
        }
        
        api.scan(&directions, &self.result);

        // ----Find closest ship and asteroid----
        let latest_result =  self.result.latest();
        let mut closest_ship = 100.0;
        let mut closest_asteroid = 100.0;
        let mut ship_id: Option<usize> = None;
        let mut asteroid_id: Option<usize> = None;

        let mut thrust = Vector2::zeros();

        for i in 0..latest_result.hits.len() {
            match latest_result.hits[i] {
                Some(hit) => { 
                    match hit.kind {
                        ct::raycast::RayHitKind::Asteroid => {
                            if hit.t < closest_asteroid {
                                closest_asteroid = hit.t;
                                asteroid_id = Some(i);
                            }
                        },
                        ct::raycast::RayHitKind::Ship => {
                            if hit.t < closest_ship {
                                closest_ship = hit.t;
                                ship_id = Some(i);
                            }
                        },
                    }
                },
                None => (),
            }
        }
        // --------------------------------------
        
        // Move away from closest asteroid
        match asteroid_id {
            Some(id) => thrust += directions[id] * 0.3,
            None => (),
        }
        
        match ship_id {
            Some(id) => {
                // Move away from closest ship
                thrust += directions[id] * 0.5;

                // Turn towards closest ship if one was found
                api.set_torque(
                    player::calculate_player_ship_torque_for_aim(directions[id], ship.rotation, ship.spin) * 0.7
                );

                // Shoot if aiming towards closest ship
                if directions[id].dot(&ship.forward()) > 0.98 {
                    api.shoot();
                }
            
            },
            None => (),
        }

        // Stay "close" to middle
        thrust += Vector2::new((ship.position.x * 1.15).powf(3.0), (ship.position.y * 1.15).powf(3.0)); 

        // Decay velocity
        thrust += ship.velocity * 0.3;

        if thrust.norm() > 0.0 {
            thrust = thrust.normalize();
        }    

        api.set_thrust(thrust);
    }
}