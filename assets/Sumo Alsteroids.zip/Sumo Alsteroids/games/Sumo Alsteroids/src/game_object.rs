use code_test_lib::prelude::*;

#[derive(Debug)]
pub enum ObjectType {
    Player,
    Enemy,
    Asteroid,
    Projectile,
}

pub struct GameObject {
    // General game object with physical properties
    pub object_type: ObjectType,
    pub position: Point2,
    pub velocity: Vector2,
    pub rotation: f32,
    pub spin: f32,
    pub radius: f32,
    pub weight: f32,
    pub collision_coefficient: f32,
    pub friction_coefficient: f32,
}

impl GameObject {
    pub fn update(&mut self, dt: f32) {
        self.position += self.velocity * dt;
        self.rotation += self.spin * dt;
    } 

    pub fn get_upcoming_collision_time(& self, other: & GameObject) -> Option<f32> {
        if !std::ptr::eq(self, other) {
            let wanted_distance = self.radius + other.radius; // d
            let wanted_distance_squared = wanted_distance.powf(2.0); // d^2

            // d^2 = a*t^2 + b*t + c (Where a, b, and c are derived from positions and velocities of the spheres)
            let a = (self.velocity[0] - other.velocity[0]).powf(2.0) + (self.velocity[1] - other.velocity[1]).powf(2.0);
            let mut b = 2.0 * (self.position[0] - other.position[0]) * (self.velocity[0] - other.velocity[0]) + 2.0 * (self.position[1] - other.position[1]) * (self.velocity[1] - other.velocity[1]);
            let mut c = (self.position[0] - other.position[0]).powf(2.0) + (self.position[1] - other.position[1]).powf(2.0);
            
            // 0 = t^2 + (b/a)*t + (c - d^2) / a
            b = b / a;
            c = (c - wanted_distance_squared) / a;
            // 0 = t^2 + bt + c (b and c updated with new values)

            // PQ-formula to find roots
            let sqrt_check = (b * 0.5).powf(2.0) - c;

            // Checks that roots are real
            if sqrt_check >= 0.0 {
                let sqrt_val = sqrt_check.sqrt();
                
                // t_1,2 = -b/2 +- sqrt((b*0.5)^2 - c)
                let t1 = -b * 0.5 - sqrt_val;
                let t2 = -b * 0.5 + sqrt_val;
                
                // Interested in smallest positive t-value
                if t1 > 0.0 {
                    if t2 > 0.0 && t2 < t1 {
                        return Option::Some(t2);
                    }
                    else {
                        return Option::Some(t1);
                    }
                } else if t2 > 0.0 {
                    return Option::Some(t2);
                }
            }
        }

        Option::None
    }

    pub fn get_post_collision_vels(& self, other: & GameObject) -> Option<(Vector2, Vector2)> {
        // This function assumes that the objects are colliding
        if !std::ptr::eq(self, other) {
            let collision_vector: Vector2 = (self.position - other.position).normalize();
            let vel_diff = other.velocity - self.velocity;

            if vel_diff.dot(&collision_vector) > 0.0 { // Moving towards each other
                let v1_dot = self.velocity.dot(&collision_vector);
                let v2_dot = other.velocity.dot(&collision_vector);

                let collision_coefficient = (self.collision_coefficient + other.collision_coefficient) * 0.5;

                let u1_dot = ((self.weight - collision_coefficient * other.weight) / (self.weight + other.weight)) * v1_dot + ((1.0 + collision_coefficient) * other.weight) / (self.weight + other.weight) * v2_dot;
                let u2_dot = ((other.weight - collision_coefficient * self.weight) / (other.weight + self.weight)) * v2_dot + ((1.0 + collision_coefficient) * self.weight) / (other.weight + self.weight) * v1_dot;

                let e = Vector2::new(collision_vector[1], -collision_vector[0]); // Collision_vector rotated 90 degrees
                    
                let friction_coefficient = (self.friction_coefficient + other.friction_coefficient) * 0.5;

                let v1 = self.velocity + (u1_dot - v1_dot) * (collision_vector - friction_coefficient * e);
                let v2 = other.velocity + (u2_dot - v2_dot) * (collision_vector - friction_coefficient * e);
                return Option::Some((v1, v2))
            }
        } 
        Option::None
    }    
}