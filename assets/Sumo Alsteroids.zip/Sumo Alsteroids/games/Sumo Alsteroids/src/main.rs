use code_test_lib as ct;
use code_test_lib::prelude::*;
use rand::Rng;

mod ai;
mod game_object;

pub use game_object::*;

// Constants to control the behaivior of the game and physics
const SHIP_COLLISION_COEFFICIENT: f32 = 0.8;
const SHIP_FRICTION_COEFFICIENT: f32 = 0.3;
const SHIP_WEIGHT: f32 = 1.0;
const ASTEROID_COLLISION_COEFFICIENT: f32 = 0.1;
const ASTEROID_FRICTION_COEFFICIENT: f32 = 0.6;
const ASTEROID_DENSITY: f32 = 50.0;
const PROJECTILE_INITIAL_SPEED: f32 = 4.0;
const PROJECTILE_COLLISION_COEFFICIENT: f32 = 0.2;
const PROJECTILE_FRICTION_COEFFICIENT: f32 = 0.7;
const PROJECTILE_WEIGHT: f32 = 0.3;
const WEAPON_FIRE_INTERVAL: f32 = 0.25;
const SPECIAL_FIRE_INTERVAL: f32 = 2.0;

fn raycast(origin: Point2, direction: Vector2, target: Point2, radius: f32) -> Option<f32> {
    let p = direction.dot(&(origin - target));
    let q = (origin - target).dot(&(origin - target)) - radius*radius;

    // Checks that roots are real
    let sqrt_check = p * p - q;
    if sqrt_check >= 0.0 {
        let sqrt = sqrt_check.sqrt();
        let t1 = -p - sqrt;
        let t2 = -p + sqrt;

        if t1 >= 0.0 {
            if t2 >= 0.0 && t2 < t1 {
                return Option::Some(t2)
            }
            else {
                return Option::Some(t1)
            }
        } else if t2 >= 0.0 {
            return Option::Some(t2)
        }
    }

    Option::None
}

fn get_random_spawn_pos() -> Point2 {
    let an_angle: f32 = rand::thread_rng().gen_range(0.0, 6.28);
    Point2::new(an_angle.cos() * 1.9, an_angle.sin() * 1.9)
}

struct Ship {
    object: GameObject,
    fire_timer: f32,
    special_timer: f32,
    thrust: Vector2,
}

// Dummy raycast handler. Needs an implementation!
struct MyRaycastHandler<'a> {
    objects: &'a Vec<&'a mut GameObject>,
}

impl ct::raycast::RaycastProcessor for MyRaycastHandler<'_> {
    fn process_raycasts(
        &self,
        _rays: &[ct::raycast::Raycast],
        _hits: &mut [Option<ct::raycast::RayHit>],
    ) {
        // Loop through every object that needs testing
        for ray_id in 0.._rays.len() {
            let mut closest_distance = 10000.0;
            let mut index: Option<usize> = None;
            
            // ----Test ray intersection, keep closest value----
            for object_id in 0..self.objects.len() {
                // Get distance
                let distance = raycast(_rays[ray_id].origin, _rays[ray_id].direction, self.objects[object_id].position, self.objects[object_id].radius);
                match distance {
                    // See if distance is within wanted interval and lower than previous closest hit
                    Some(d) => if d > _rays[ray_id].t_min && d < _rays[ray_id].t_max && d < closest_distance {
                        // Save distance and index to object
                        closest_distance = d;
                        index = Some(object_id);
                    },
                    None => (),
                }
            }
            // -------------------------------------------------

            match index {
                // Some means a valid hit was found
                Some(i) => _hits[ray_id] = Some(ct::raycast::RayHit{
                    kind: match self.objects[i].object_type {
                        ObjectType::Player => ct::raycast::RayHitKind::Ship,
                        ObjectType::Enemy => ct::raycast::RayHitKind::Ship,
                        ObjectType::Asteroid => ct::raycast::RayHitKind::Asteroid,
                        _ => ct::raycast::RayHitKind::Asteroid, // See projectile as asteroid
                    },
                    t: closest_distance
                }),
                None => (),
            }
        }
    }
}

struct MyGame {
    round: i32,
    count_down_timer: f32,

    // Player's ship and behaivior.
    player: Ship,
    player_behavior: ct::player::PlayerShipBehavior,

    // std::sync::mpsc::SyncSender for player input. PlayerShipBehavior receives it every frame.
    player_input_tx: SyncSender<ct::player::PlayerInput>,

    // Utilities for drawing the ship.
    gfx_util: ct::gfx::GfxUtil,

    // Necessary to evaluate ship behaviors, even the player's.
    ship_behavior_processor: ct::behavior::ShipBehaviorProcessor,

    // Add enemy ships, asteroids etc
    asteroids: Vec<GameObject>,
    enemies: Vec<(Ship, ai::AIShipBehavior)>,
    projectiles: Vec<GameObject>,

    // Play border
    border: Vec<ct::gfx::ProjectileDrawData>,
}

// Main entry points for the Code Test game.
impl ct::game::CodeTestImpl for MyGame {
    fn new(ctx: &mut Context) -> Self {

        let (player_input_tx, player_input_rx) = sync_channel(1);

        Self {
            round: 0,
            count_down_timer: 0.0,
            player: Ship {
                object: GameObject {
                    object_type: ObjectType::Player,
                    position: Point2::new(0.0, 0.0),
                    velocity: Vector2::zeros(),
                    rotation: 0.0,
                    spin: 0.0,
                    radius: ct::SHIP_RADIUS,
                    weight: SHIP_WEIGHT,
                    collision_coefficient: SHIP_COLLISION_COEFFICIENT,
                    friction_coefficient: SHIP_FRICTION_COEFFICIENT,
                },
                fire_timer: 0.0,
                special_timer: 0.0,
                thrust: Vector2::zeros(),
            },

            player_behavior: ct::player::PlayerShipBehavior::new(player_input_rx),
            player_input_tx,
            gfx_util: ct::gfx::GfxUtil::new(ctx),
            ship_behavior_processor: ct::behavior::ShipBehaviorProcessor::new(),

            asteroids: Vec::new(),
            enemies: Vec::new(),
            projectiles: Vec::new(),

            border: Vec::new(),
        }
    }

    fn update(&mut self, ctx: &mut Context, player_input: ct::player::PlayerInput) {
        // Duration::as_float_secs is unstable, so we calculate it ourselves
        let dt: f32 = timer::delta(ctx).subsec_nanos().min(100_000_000) as f32 * 1e-9;

        // Center the camera around the origin, and calculate its transformations.
        // We need them here for mouse aim.
        self.gfx_util
            .calculate_view_transform(ctx, Point2::origin(), 1.0);

        // Start new round if all enemies are killed
        if self.enemies.len() == 0 {
            self.start_round(self.round + 1);
        }

        // Don't update if counting down
        if self.count_down_timer > 0.0 {
            self.count_down_timer -= dt;
            return;
        }

        // Use the calculated camera transformation to find the word position
        // of the mouse cursor, and send the input to the player ship behavior.
        self.player_input_tx
            .send(self.gfx_util.screen_to_world(player_input))
            .ok();

        // ----Update player behaivior----
        // if player goes outside play area, go back one round
        if self.player.object.position.x.abs() > 1.0 + ct::SHIP_RADIUS || self.player.object.position.y.abs() > 1.0 + ct::SHIP_RADIUS {
            self.start_round((self.round - 1).max(1));
        }
        
        self.ship_behavior_processor.run_behaviors(
            std::iter::once((
                ct::behavior::BehaviorShipInfo {
                    position: self.player.object.position,
                    velocity: self.player.object.velocity,
                    rotation: self.player.object.rotation,
                    spin: self.player.object.spin,
                },
                &mut self.player_behavior as &mut dyn ct::behavior::ShipBehavior,
            )),
            &ct::behavior::BehaviorGameInfo { safe_radius: 1.0 },
            dt,
        );

        let player_action = &self.ship_behavior_processor.get_actions()[0];

        // In-place update the ship state based using a simple simulation model.
        // Throw away position variable since I want to update the position in the continous collision update instead
        // Making the simulation only update the velocity, rotation, and spin
        let mut _trash_pos: Point2 = Point2::new(0.0, 0.0);
        ct::sim::simulate_ship(
            player_action.controls,
            dt,
            &mut _trash_pos,
            &mut self.player.object.velocity,
            &mut self.player.object.rotation,
            &mut self.player.object.spin,
        );

        // Store the player ship's thrust, as it's useful for rendering engine plumes!
        self.player.thrust = player_action.controls.thrust;

        // Shoot some bullets!
        if player_action.shoot && self.player.fire_timer <= 0.0 {
            self.fire_projectile(self.player.object.position, self.player.object.rotation, PROJECTILE_INITIAL_SPEED);
            self.player.fire_timer = WEAPON_FIRE_INTERVAL;
        }

        // Use special, a triple shot attack
        if player_input.special && self.player.special_timer <= 0.0 {
            let right_vec = Vector2::new(self.player.object.rotation.cos(), self.player.object.rotation.sin());
            
            for i in -1..2 {
                self.fire_projectile(self.player.object.position + i as f32 * right_vec * 0.03, self.player.object.rotation, PROJECTILE_INITIAL_SPEED);
            }
            
            self.player.special_timer = SPECIAL_FIRE_INTERVAL;
        }
        
        // Decrease player timers
        self.player.fire_timer -= dt;
        self.player.special_timer -= dt;
        // -------------------------------

        // ----Update asteroids behaivior----
        for x in self.asteroids.iter_mut() {
            // Send asteroids towards play area if they have escaped
            if x.position[0].abs() > 2.0 || x.position[1].abs() > 2.0 {
                x.position = get_random_spawn_pos();
                x.velocity[0] = -x.position[0] * rand::thread_rng().gen_range(0.5, 1.0);
                x.velocity[1] = -x.position[1] * rand::thread_rng().gen_range(0.5, 1.0); 
                x.velocity = x.velocity.normalize() * 0.7;
            }
        }
        // ----------------------------------

        // ----Update enemies behaivior----
        // Kill enemies outside play area
        self.enemies.retain(|(x, _)| !(x.object.position[0].abs() > 1.0 + ct::SHIP_RADIUS || x.object.position[1].abs() > 1.0 + ct::SHIP_RADIUS));

        // Run behaivior for the remaining enemies
        self.ship_behavior_processor.run_behaviors(
            self.enemies.iter_mut().map(|(x, y)| (
                ct::behavior::BehaviorShipInfo {
                    position: x.object.position,
                    velocity: x.object.velocity,
                    rotation: x.object.rotation,
                    spin: x.object.spin,
                },
                y as &mut dyn ct::behavior::ShipBehavior,
            )),
            &ct::behavior::BehaviorGameInfo { safe_radius: 1.0 },
            dt,
        );

        for (i, (x, _)) in self.enemies.iter_mut().enumerate() {
            // In-place update the ship state based using a simple simulation model.
            // Throw away position variable since I want to update the position in the continous collision update instead
            // Making the simulation only update the velocity, rotation, and spin
            let actions = self.ship_behavior_processor.get_actions()[i].controls;
            ct::sim::simulate_ship(
                actions,
                dt,
                &mut _trash_pos,
                &mut x.object.velocity,
                &mut x.object.rotation,
                &mut x.object.spin,
            );

            // Save thrust for drawing engine plumes
            x.thrust = actions.thrust;
        }

        // Let the enemies shoot if requested and not on cool down
        for i in 0..self.enemies.len() {
            if self.ship_behavior_processor.get_actions()[i].shoot && self.enemies[i].0.fire_timer <= 0.0 {
                self.fire_projectile(self.enemies[i].0.object.position, 
                    self.enemies[i].0.object.rotation, 
                    PROJECTILE_INITIAL_SPEED);
                self.enemies[i].0.fire_timer = WEAPON_FIRE_INTERVAL;
            }

            self.enemies[i].0.fire_timer -= dt;
        }
        // --------------------------------

        // ----Update projectiles behaivior----
        // Remove projectiles that are moving slow or positioned too far away
        self.projectiles.retain(|x| !(x.velocity.norm() < PROJECTILE_INITIAL_SPEED * 0.8 || x.position[0].abs() > 2.0 || x.position[1].abs() > 2.0));
        // ------------------------------------

        // Gather all objects as they are needed for raycasts and collisions
        let mut all_objects: Vec<&mut GameObject> = self.asteroids.iter_mut().chain(self.enemies.iter_mut().map(|(x, _y)| &mut x.object).chain(self.projectiles.iter_mut())).collect();
        all_objects.push(&mut self.player.object);

        // Once behaviors have executed, evaluate their visibility raycasts,
        // as they will be needed in the next frame.
        self.ship_behavior_processor
            .process_raycasts(&MyRaycastHandler{
                objects: &all_objects,
            });

        // ----Collide things!----
        // Continously, wooow!
        let mut collision_order: Vec<(f32, usize, usize)> = Vec::new();

        // 1. Find all upcoming collisions, save time until collision and the objects colliding in a list
        for i in 0..all_objects.len() {
            // Get collision time for all objects
            for j in i+1..all_objects.len() {
                let time = all_objects[i].get_upcoming_collision_time(&all_objects[j]);
                match time {
                    Some(the_time) => {
                        // Save the time if it happens before this frame is over
                        if the_time <= dt {
                            collision_order.push((the_time, i, j));
                        };
                    },
                    None => (),
                }
            }
        }
        
        let mut time_processed = 0.0;
        // 2. Sort the list by time
        collision_order.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());

        if collision_order.len() > 0 {
            loop {
                // 3. Advance all objects until collision (and a little further to avoid looping forever)
                for i in 0..all_objects.len() {
                    all_objects[i].update(collision_order[0].0 - time_processed + dt/100.0);
                }

                time_processed = collision_order[0].0;

                // 4. Handle collision of the two objects
                let ids = [collision_order[0].1, collision_order[0].2];
                let vel_tup = all_objects[ids[0]].get_post_collision_vels(&all_objects[ids[1]]);
                match vel_tup {
                    Some(vel) => {
                        all_objects[ids[0]].velocity = vel.0;
                        all_objects[ids[1]].velocity = vel.1;
                    },
                    None => (),
                }

                // 5. Remove all collisions for these objects in the list
                collision_order.retain(|&x| x.1 != ids[0] && x.2 != ids[0] && x.1 != ids[1] && x.2 != ids[1]);

                // 6. Recheck next collision for these objects and add to the list
                for i in 0..2 {
                    for j in 0..all_objects.len() {
                        let time = all_objects[ids[i]].get_upcoming_collision_time(&all_objects[j]);
                        match time {
                            Some(the_time) => {
                                // Save the time if it happens before this frame is over
                                if the_time + time_processed <= dt {
                                    collision_order.push((the_time + time_processed, ids[i], j));
                                }
                            },
                            None => (),
                        }
                    }
                }

                // 7. Repeat 2-6 until no time or no collisions remain
                collision_order.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());

                if collision_order.len() == 0 || collision_order[0].0 > dt {break;}
            } 
        }

        // 8. Advance all objects if dt has not been reached
        for i in 0..all_objects.len() {
            all_objects[i].update(dt - time_processed);
        }
        // -----------------------
    }

    fn draw(&mut self, ctx: &mut Context) {
        graphics::clear(ctx, graphics::Color::new(0.1, 0.1, 0.2, 1.0));

        self.gfx_util.apply_view_transform(ctx);

        // Draw player
        self.gfx_util.draw_ships(
            ctx,
            std::iter::once(ct::gfx::ShipDrawData {
                position: self.player.object.position,
                rotation: self.player.object.rotation,
                thrust: self.player.thrust,
                ship_type: ct::gfx::DrawShipType::Player,
            }),
        );

        // Draw enemies
        self.gfx_util.draw_ships(
            ctx,
            self.enemies.iter().map(|(value, _)| ct::gfx::ShipDrawData{
                position: value.object.position,
                rotation: value.object.rotation,
                thrust: value.thrust,
                ship_type: ct::gfx::DrawShipType::Enemy 
            }),
        );
        
        self.gfx_util.draw_asteroids(
            ctx,
            self.asteroids.iter().map(|value| ct::gfx::AsteroidDrawData{
                position: value.position,
                rotation: value.rotation,
                radius: value.radius,
            }),
        );

        self.gfx_util.draw_projectiles(
            ctx,
            self.projectiles.iter().map(|value| ct::gfx::ProjectileDrawData {
                position: value.position,
                rotation: (-value.velocity.x).atan2(value.velocity.y),
            }),
        );

        // Draw projectiles as play border
        self.gfx_util.draw_projectiles(
            ctx,
            self.border.iter().map(|value| ct::gfx::ProjectileDrawData {
                position: value.position,
                rotation: value.rotation,
            }),
        );

        // Draw projectiles as count down
        self.gfx_util.draw_projectiles(
            ctx,
            (0..self.count_down_timer.ceil() as i32).into_iter().map(
                |count| ct::gfx::ProjectileDrawData {
                    position: Point2::new(-0.1 + 0.1 * count as f32, 0.3),
                    rotation: 0.0,
            }),
        );
    }

}

impl MyGame {
    // ----Support functions----
    fn start_round(&mut self, round: i32) {
        self.round = round;
        self.count_down_timer = 3.0;

        self.asteroids.clear();
        self.projectiles.clear();
        self.enemies.clear();

        self.set_up();
    }

    fn set_up(&mut self) {
        // ----Reset player----
        self.player.object.position = Point2::new(0.0, 0.0);
        self.player.object.velocity = Vector2::zeros();
        self.player.object.rotation = 0.0;
        self.player.object.spin = 0.0;

        self.player.fire_timer= 0.0;
        self.player.special_timer = 0.0;
        self.player.thrust = Vector2::zeros();
        // --------------------

        // ----Make some asteroids!----
        while self.asteroids.len() < 6 + self.round as usize {
            let a_position = get_random_spawn_pos();
            let size = rand::thread_rng().gen_range(0.04, 0.1);
            self.asteroids.push(GameObject{
                object_type: ObjectType::Asteroid,
                position: a_position,
                velocity: Vector2::new
                    (-a_position[0] * rand::thread_rng().gen_range(0.5, 1.0)
                    , -a_position[1] * rand::thread_rng().gen_range(0.5, 1.0)).normalize() * 0.7,
                rotation: 0.0,
                spin: 4.0,
                radius: size,
                weight: size * ASTEROID_DENSITY,
                collision_coefficient: ASTEROID_COLLISION_COEFFICIENT,
                friction_coefficient: ASTEROID_FRICTION_COEFFICIENT,
            });
        }
        // ----------------------------
        
        // ----Make some enemies!----
        while self.enemies.len() < self.round as usize {
            let a_position = Point2::new(rand::thread_rng().gen_range(-1.0, 1.0), rand::thread_rng().gen_range(-1.0, 1.0));
            self.enemies.push((Ship {
                object: GameObject {
                    object_type: ObjectType::Enemy,
                    position: a_position,
                    velocity: Vector2::zeros(),
                    rotation: 0.0,
                    spin: 0.0,
                    radius: ct::SHIP_RADIUS,
                    weight: SHIP_WEIGHT,
                    collision_coefficient: SHIP_COLLISION_COEFFICIENT,
                    friction_coefficient: SHIP_FRICTION_COEFFICIENT,
                },
                fire_timer: 0.0,
                special_timer: 0.0,
                thrust: Vector2::zeros(),
            }, ai::AIShipBehavior::new(),
            ));
        }
        // --------------------------

        // ----Create border----
        if self.border.len() == 0 {
            for i in 0..17 {
                self.border.push(ct::gfx::ProjectileDrawData {
                    position: Point2::new(-0.95 + (1.9 / 16.0) * i as f32, -0.95), 
                    rotation: 1.57,
                });
                self.border.push(ct::gfx::ProjectileDrawData {
                    position: Point2::new(-0.95, -0.95 + (1.9 / 16.0) * i as f32), 
                    rotation: 0.0,
                });
                self.border.push(ct::gfx::ProjectileDrawData {
                    position: Point2::new(-0.95 + (1.9 / 16.0) * i as f32, 0.95), 
                    rotation: 1.57,
                });
                self.border.push(ct::gfx::ProjectileDrawData {
                    position: Point2::new(0.95, -0.95 + (1.9 / 16.0) * i as f32), 
                    rotation: 0.0,
                });
            }
        }
        // ---------------------
    }

    fn fire_projectile(&mut self, position: Point2, angle: f32, speed: f32) {
        self.projectiles.push(GameObject{
            object_type: ObjectType::Projectile,
                position: position,
                velocity: Vector2::new((angle + 1.57).cos() * speed, (angle + 1.57).sin() * speed),
                rotation: angle,
                spin: 0.0,
                radius: 0.01,
                weight: PROJECTILE_WEIGHT,
                collision_coefficient: PROJECTILE_COLLISION_COEFFICIENT,
                friction_coefficient: PROJECTILE_FRICTION_COEFFICIENT,
        });
    }
    // -------------------------
}

fn main() -> GameResult {
    ct::game::run::<MyGame>()
}
