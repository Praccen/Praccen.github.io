use super::{raycast::*, Point2, Vector2, SHIP_RADIUS};
use std::cell::Cell;
use std::rc::Rc;

/// Number of visibility rays a ship behavior can shoot per tick.
pub const SENSOR_RESOLUTION: usize = 32;

/// Global game information that ship behavior implementations need.
pub struct BehaviorGameInfo {
    /// Radius of an origin-centered circle within which all ships should strive to remain.
    /// Can be used to concentrate the heat of the action.
    pub safe_radius: f32,
}

/// Information about an individual ship.
pub struct BehaviorShipInfo {
    pub position: Point2,
    pub velocity: Vector2,

    /// Rotation in radians. Counter-clockwise, zero degrees means pointing up.
    pub rotation: f32,

    // Angular velocity in radians. Counter-clockwise.
    pub spin: f32,
}

impl BehaviorShipInfo {
    /// Get a forward direction vector.
    pub fn forward(&self) -> Vector2 {
        Vector2::new(-self.rotation.sin(), self.rotation.cos())
    }
}

/// Results of a previous ship sensor `scan()` request.
#[derive(Clone, Copy)]
pub struct SensorScanResultPayload {
    /// Hits or None if they ray missed
    pub hits: [Option<RayHit>; SENSOR_RESOLUTION],

    /// Directions towards which the scan was performed
    pub directions: [Vector2; SENSOR_RESOLUTION],

    /// The point from which the scan was performed
    pub origin: Point2,
}

impl Default for SensorScanResultPayload {
    fn default() -> Self {
        Self {
            hits: Default::default(),
            directions: [Vector2::zeros(); SENSOR_RESOLUTION],
            origin: Point2::origin(),
        }
    }
}

/// Wrapper over sensor scan results; allows easy interaction with the ship API.
#[derive(Clone, Default)]
pub struct SensorScanResult {
    latest: SensorScanResultPayload,
    pending: Rc<Cell<Option<SensorScanResultPayload>>>,
}

impl SensorScanResult {
    /// Get the scan results from the previous tick.
    pub fn latest(&mut self) -> &SensorScanResultPayload {
        if let Some(value) = self.pending.take() {
            self.latest = value;
        }
        &self.latest
    }
}

/// The interface a ship behavior interacts with.
pub trait ShipBehaviorApi {
    /// Set the engine thrust. Should be opposite to the desired acceleration vector.
    fn set_thrust(&mut self, direction: Vector2);

    /// Set the rotational torque that the ship will apply. Positive values apply counter-clockwise acceleration.
    ///
    /// Please see the souce of `PlayerShipBehavior` for an example of calculating torque to aim in a specific direction.
    fn set_torque(&mut self, amount: f32);

    /// Request to shoot (actual shooting needs to be implemented externally).
    fn shoot(&mut self);

    /// Perform a scan by shooting [`SENSOR_RESOLUTION`](constant.SENSOR_RESOLUTION.html) rays around the ship
    /// in the specified directions.
    ///
    /// This is how a ship can find out what's around it. The raycast does not run immediately, but only after the call to
    /// `ShipBehaviorProcessor::process_raycasts()`, meaning that in practice, the behavior works with hit results
    /// from the previous simulation tick. The results are returned written into the `SensorScanResult` container provided.
    fn scan(&mut self, directions: &[Vector2; SENSOR_RESOLUTION], result: &SensorScanResult);
}

/// Implement this trait to define a custom ship behavior!
///
/// Every tick, the ship will have a chance to inspect state, and take actions.
///
/// # Arguments
/// * `ship` - Information about the ship running the behavior.
/// * `game` - Global information about the game state.
/// * `dt` - Delta time for this simulation period, in seconds.
/// * `api` - The API through which the behavior can take actions.
pub trait ShipBehavior {
    fn behave(
        &mut self,
        ship: &BehaviorShipInfo,
        game: &BehaviorGameInfo,
        dt: f32,
        api: &mut dyn ShipBehaviorApi,
    );
}

/// Ship controls requested by a ship behavior.
#[derive(Clone, Copy)]
pub struct ShipControls {
    pub thrust: Vector2,
    pub torque: f32,
}

/// Ship actions requested by a ship behavior.
#[derive(Clone)]
pub struct ShipAction {
    pub controls: ShipControls,
    pub shoot: bool,
    pub scan: Option<SensorScanRequest>,
}

impl Default for ShipAction {
    fn default() -> Self {
        Self {
            controls: ShipControls {
                thrust: Vector2::zeros(),
                torque: 0.0,
            },
            shoot: false,
            scan: None,
        }
    }
}

/// A helper that runs ship behaviors, performs visibility raycasts, and provides calculated ship actions.
#[derive(Default)]
pub struct ShipBehaviorProcessor {
    ship_actions: Vec<ShipAction>,
    scan_origins: Vec<Option<Point2>>,
    raycasts: Vec<Raycast>,
    request_raycast_offset: Vec<Option<usize>>,
    hits: Vec<Option<RayHit>>,
}

#[derive(Clone)]
pub struct SensorScanRequest {
    directions: [Vector2; SENSOR_RESOLUTION],
    result: SensorScanResult,
}

struct ShipApiProvider {
    action: ShipAction,
}

impl ShipApiProvider {
    fn new() -> Self {
        Self {
            action: Default::default(),
        }
    }
}

impl ShipBehaviorApi for ShipApiProvider {
    fn set_thrust(&mut self, direction: Vector2) {
        self.action.controls.thrust = direction;
    }

    fn set_torque(&mut self, value: f32) {
        self.action.controls.torque = value;
    }

    fn shoot(&mut self) {
        self.action.shoot = true;
    }

    fn scan(&mut self, directions: &[Vector2; SENSOR_RESOLUTION], result: &SensorScanResult) {
        self.action.scan = Some(SensorScanRequest {
            directions: *directions,
            result: result.clone(),
        });
    }
}

impl ShipBehaviorProcessor {
    pub fn new() -> Self {
        Self {
            ship_actions: Vec::new(),
            scan_origins: Vec::new(),
            raycasts: Vec::new(),
            request_raycast_offset: Vec::new(),
            hits: Vec::new(),
        }
    }

    fn clear(&mut self) {
        self.ship_actions.clear();
        self.scan_origins.clear();
        self.raycasts.clear();
        self.request_raycast_offset.clear();
        self.hits.clear();
    }

    /// Run the supplied ship behaviors, and store their desired actions.
    ///
    /// # Arguments
    /// * `behavior_ship_infos` - An iterator over pairs of matching ship info and behavior.
    /// * `game_info` - Global information about the game state for use by all behaviors.
    /// * `dt` - Delta time for this simulation period, in seconds.
    pub fn run_behaviors<'a, Iter>(
        &mut self,
        behavior_ship_infos: Iter,
        game_info: &BehaviorGameInfo,
        dt: f32,
    ) where
        Iter: Iterator<Item = (BehaviorShipInfo, &'a mut dyn ShipBehavior)>,
    {
        self.clear();

        for (behavior_ship_info, behavior) in behavior_ship_infos {
            let action = {
                let mut api_provider = ShipApiProvider::new();
                behavior.behave(&behavior_ship_info, &game_info, dt, &mut api_provider);
                api_provider.action
            };

            self.scan_origins.push(if action.scan.is_some() {
                Some(behavior_ship_info.position)
            } else {
                None
            });

            self.ship_actions.push(action);
        }

        self.prepare_raycasts();
    }

    /// Having run ship behaviors, process the raycasts they generated. They will feed
    /// the next iteration of behavior evaluation.
    pub fn process_raycasts(&mut self, raycast_provider: &dyn RaycastProcessor) {
        let ship_count = self.ship_actions.len();

        raycast_provider.process_raycasts(&self.raycasts, &mut self.hits);

        for ship_i in 0..ship_count {
            if let Some(scan_origin) = self.scan_origins[ship_i] {
                let slice_begin = self.request_raycast_offset[ship_i].unwrap();
                let slice_end = slice_begin + SENSOR_RESOLUTION;

                let mut hits_slice: [Option<RayHit>; SENSOR_RESOLUTION] = [None; SENSOR_RESOLUTION];
                hits_slice[0..SENSOR_RESOLUTION]
                    .clone_from_slice(&self.hits[slice_begin..slice_end]);

                let srq = self.ship_actions[ship_i].scan.as_ref().unwrap();

                srq.result.pending.set(Some(SensorScanResultPayload {
                    hits: hits_slice,
                    directions: self.ship_actions[ship_i].scan.as_ref().unwrap().directions,
                    origin: scan_origin,
                }));
            }
        }
    }

    /// Get the actions that ships generated. Useful for visualization, shooting, etc.
    pub fn get_actions(&self) -> &[ShipAction] {
        &self.ship_actions
    }

    fn prepare_raycasts(&mut self) {
        for (ship_i, scan_origin) in self.scan_origins.iter().enumerate() {
            // Make sure we don't self-intersect
            let ray_offset = SHIP_RADIUS * 1.001;

            if let Some(origin) = scan_origin {
                self.request_raycast_offset.push(Some(self.raycasts.len()));

                let directions = &self.ship_actions[ship_i].scan.as_ref().unwrap().directions;

                self.raycasts
                    .extend((0..SENSOR_RESOLUTION).map(|i| Raycast {
                        origin: *origin,
                        direction: directions[i],
                        t_min: ray_offset,
                        t_max: std::f32::MAX,
                    }));
            } else {
                self.request_raycast_offset.push(None);
            }
        }

        self.hits.resize(self.raycasts.len(), None);
    }
}
