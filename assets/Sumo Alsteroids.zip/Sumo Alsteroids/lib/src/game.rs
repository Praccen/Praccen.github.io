use super::player::*;

use ggez::event::{self, KeyCode, KeyMods, MouseButton};
use ggez::graphics;
use ggez::nalgebra::Point2;
use ggez::{Context, GameResult};

/// Implement this trait to define your game!
pub trait CodeTestImpl {
    fn new(ctx: &mut Context) -> Self;
    fn update(&mut self, ctx: &mut Context, player_input: PlayerInput);
    fn draw(&mut self, ctx: &mut Context);
}

/// Call this in your `main()` function in order to run your game.
///
/// This function will create a window, and set up basic event handling.The provided game type will
/// then be instantiated via the `new` function, and the main game loop will start.
pub fn run<GameImpl>() -> GameResult
where
    GameImpl: CodeTestImpl,
{
    // Here we use a ContextBuilder to setup metadata about our game. First the title and author
    let (ctx, events_loop) = &mut ggez::ContextBuilder::new("hello_embark", "Ferris Crab")
        .window_setup(ggez::conf::WindowSetup::default().title("Hello, Embark!"))
        .window_mode(ggez::conf::WindowMode::default().resizable(true))
        .add_resource_path(&std::env::current_dir().unwrap())
        .build()
        .expect("Window failed to build");

    let mut game: CodeTestGame<GameImpl> = CodeTestGame::new(CodeTestImpl::new(ctx));
    event::run(ctx, events_loop, &mut game)
}

struct CodeTestGame<Impl>
where
    Impl: CodeTestImpl,
{
    player_input: PlayerInput,
    code_test_impl: Impl,
}

impl<Impl> CodeTestGame<Impl>
where
    Impl: CodeTestImpl,
{
    fn new(code_test_impl: Impl) -> Self {
        Self {
            player_input: PlayerInput::new(),
            code_test_impl,
        }
    }

    fn handle_key(&mut self, keycode: KeyCode, value: bool) {
        match keycode {
            KeyCode::W | KeyCode::Up => self.player_input.up = value,
            KeyCode::A | KeyCode::Left => self.player_input.left = value,
            KeyCode::S | KeyCode::Down => self.player_input.down = value,
            KeyCode::D | KeyCode::Right => self.player_input.right = value,
            KeyCode::Space => self.player_input.special = value,
            _ => (),
        }
    }
}

impl<Impl> event::EventHandler for CodeTestGame<Impl>
where
    Impl: CodeTestImpl,
{
    fn mouse_motion_event(&mut self, _ctx: &mut Context, x: f32, y: f32, _dx: f32, _dy: f32) {
        self.player_input.cursor_pos = CursorPos::ScreenPixels(Point2::new(x, y));
    }

    fn mouse_button_down_event(&mut self, _ctx: &mut Context, _b: MouseButton, _x: f32, _y: f32) {
        self.player_input.shoot = true;
    }

    fn mouse_button_up_event(&mut self, _ctx: &mut Context, _b: MouseButton, _x: f32, _y: f32) {
        self.player_input.shoot = false;
    }

    fn key_down_event(
        &mut self,
        _ctx: &mut Context,
        keycode: KeyCode,
        _keymods: KeyMods,
        _repeat: bool,
    ) {
        self.handle_key(keycode, true);
    }

    fn key_up_event(&mut self, _ctx: &mut Context, keycode: KeyCode, _keymods: KeyMods) {
        self.handle_key(keycode, false);
    }

    fn update(&mut self, ctx: &mut Context) -> GameResult<()> {
        self.code_test_impl.update(ctx, self.player_input);
        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult<()> {
        let window_size = graphics::size(ctx);
        let new_rect = graphics::Rect::new(0.0, 0.0, window_size.0 as f32, window_size.1 as f32);
        graphics::set_screen_coordinates(ctx, new_rect).unwrap();
        graphics::apply_transformations(ctx).unwrap();

        self.code_test_impl.draw(ctx);
        graphics::present(ctx)
    }
}
