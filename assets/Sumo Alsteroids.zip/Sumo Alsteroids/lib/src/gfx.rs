use super::player::{CursorPos, PlayerInput};
use super::{Point2, Vector2, SHIP_RADIUS};

use ggez::graphics;
use ggez::nalgebra::{self as na};
use ggez::Context;

type Matrix4 = ggez::nalgebra::Matrix4<f32>;

/// State for graphics utilities.
pub struct GfxUtil {
    pub asteroid_image_dims: (u32, u32),
    pub asteroid_spritebatch: graphics::spritebatch::SpriteBatch,

    pub projectile_image_dims: (u32, u32),
    pub projectile_spritebatch: graphics::spritebatch::SpriteBatch,

    pub player_image: graphics::Image,
    pub enemy_image: graphics::Image,
    pub engine_plume_image: graphics::Image,

    pub world_to_screen: Matrix4,
    pub screen_to_world: Matrix4,
}

pub struct ProjectileDrawData {
    pub position: Point2,
    pub rotation: f32,
}

pub struct AsteroidDrawData {
    pub position: Point2,
    pub rotation: f32,
    pub radius: f32,
}

#[derive(PartialEq, Clone, Copy)]
pub enum DrawShipType {
    Player,
    Enemy,
}

pub struct ShipDrawData {
    pub position: Point2,
    pub rotation: f32,
    pub thrust: Vector2, // world-space
    pub ship_type: DrawShipType,
}

/// Conversion from screen-space pixels to world coordinates. Useful for mouse aim.
pub trait ScreenToWorld<T> {
    fn screen_to_world(&self, pt: T) -> T;
}

impl ScreenToWorld<Point2> for GfxUtil {
    fn screen_to_world(&self, pt: Point2) -> Point2 {
        let pt = self.screen_to_world * na::Vector4::new(pt.x as f32, pt.y as f32, 0.0, 1.0);
        Point2::new(pt.x, pt.y)
    }
}

impl ScreenToWorld<CursorPos> for GfxUtil {
    fn screen_to_world(&self, pt: CursorPos) -> CursorPos {
        match pt {
            CursorPos::ScreenPixels(pt) => {
                let pt =
                    self.screen_to_world * na::Vector4::new(pt.x as f32, pt.y as f32, 0.0, 1.0);
                CursorPos::WorldSpace(Point2::new(pt.x, pt.y))
            }
            _ => panic!("ScreenToWorld: Input already in screen space"),
        }
    }
}

impl ScreenToWorld<PlayerInput> for GfxUtil {
    fn screen_to_world(&self, mut player_input: PlayerInput) -> PlayerInput {
        player_input.cursor_pos = ScreenToWorld::screen_to_world(self, player_input.cursor_pos);
        player_input
    }
}

impl GfxUtil {
    /// Load assets and create instance
    pub fn new(ctx: &mut Context) -> Self {
        let asteroid_image = graphics::Image::new(ctx, "/lib/assets/asteroid.png").unwrap();
        let asteroid_image_dims = (
            asteroid_image.width() as u32,
            asteroid_image.height() as u32,
        );
        let asteroid_spritebatch = graphics::spritebatch::SpriteBatch::new(asteroid_image);

        let projectile_image = graphics::Image::new(ctx, "/lib/assets/projectile.png").unwrap();
        let projectile_image_dims = (
            projectile_image.width() as u32,
            projectile_image.height() as u32,
        );
        let projectile_spritebatch = graphics::spritebatch::SpriteBatch::new(projectile_image);

        let player_image = graphics::Image::new(ctx, "/lib/assets/player.png").unwrap();
        let enemy_image = graphics::Image::new(ctx, "/lib/assets/enemy.png").unwrap();
        let engine_plume_image = graphics::Image::new(ctx, "/lib/assets/engine_plume.png").unwrap();

        GfxUtil {
            asteroid_image_dims,
            asteroid_spritebatch,
            projectile_image_dims,
            projectile_spritebatch,
            player_image,
            enemy_image,
            engine_plume_image,
            world_to_screen: Matrix4::identity(),
            screen_to_world: Matrix4::identity(),
        }
    }

    /// Calculate 2D camera transformations looking at the specified `origin`, with the given `scale`.
    ///
    /// Note: The transformation is not immediately applied to the rendering context, and needs
    /// to be applied using `apply_view_transform`. It does however become immediately usable via
    /// the [`ScreenToWorld`](trait.ScreenToWorld.html) trait.
    pub fn calculate_view_transform(&mut self, ctx: &Context, origin: Point2, scale: f32) {
        let window_size = graphics::size(ctx);

        let viewport_transform = Matrix4::new_translation(&na::Vector3::new(
            window_size.0 as f32 * 0.5,
            window_size.1 as f32 * 0.5,
            0.0,
        )) * Matrix4::new_nonuniform_scaling(&na::Vector3::new(
            window_size.1 as f32 * 0.5,
            window_size.1 as f32 * 0.5,
            1.0,
        ));

        self.world_to_screen = viewport_transform
            * Matrix4::new_nonuniform_scaling(&na::Vector3::new(scale, -scale, 1.0))
            * Matrix4::new_translation(&na::Vector3::new(-origin.x, -origin.y, 0.0));

        self.screen_to_world = self.world_to_screen.try_inverse().unwrap();
    }

    /// Apply the calculated view transform to the current graphics context
    pub fn apply_view_transform(&self, ctx: &mut Context) {
        graphics::set_transform(ctx, self.world_to_screen);
        graphics::apply_transformations(ctx).unwrap();
    }

    /// Draw projectiles given an iterator over [`ProjectileDrawData`](struct.ProjectileDrawData.html).
    pub fn draw_projectiles<Iter>(&mut self, ctx: &mut Context, projectiles: Iter)
    where
        Iter: Iterator<Item = ProjectileDrawData>,
    {
        for p in projectiles {
            {
                let half_w = 0.015 / self.projectile_image_dims.0 as f32;
                let half_h = 0.045 / self.projectile_image_dims.1 as f32;
                let p = graphics::DrawParam::new()
                    .dest(p.position - Vector2::new(0.5, 0.5))
                    .scale(Vector2::new(half_w * 2.0, half_h * 2.0))
                    .offset(Point2::new(0.5, 0.5))
                    .rotation(p.rotation);
                self.projectile_spritebatch.add(p);
            }
        }

        graphics::draw(
            ctx,
            &self.projectile_spritebatch,
            graphics::DrawParam::new(),
        )
        .unwrap();
        self.projectile_spritebatch.clear();
    }

    /// Draw asteroids given an iterator over [`AsteroidDrawData`](struct.AsteroidDrawData.html).
    pub fn draw_asteroids<Iter>(&mut self, ctx: &mut Context, asteroids: Iter)
    where
        Iter: Iterator<Item = AsteroidDrawData>,
    {
        for a in asteroids {
            {
                let half_w = a.radius / self.asteroid_image_dims.0 as f32;
                let half_h = a.radius / self.asteroid_image_dims.1 as f32;
                let p = graphics::DrawParam::new()
                    .dest(a.position - Vector2::new(0.5, 0.5))
                    .scale(Vector2::new(half_w * 2.0, half_h * 2.0) * 1.1) // Expand to account for padding in the image
                    .offset(Point2::new(0.5, 0.5))
                    .rotation(a.rotation);
                self.asteroid_spritebatch.add(p);
            }
        }

        graphics::draw(ctx, &self.asteroid_spritebatch, graphics::DrawParam::new()).unwrap();
        self.asteroid_spritebatch.clear();
    }

    /// Draw ships given an iterator over [`ShipDrawData`](struct.ShipDrawData.html).
    pub fn draw_ships<Iter>(&mut self, ctx: &mut Context, ships: Iter)
    where
        Iter: Iterator<Item = ShipDrawData>,
    {
        for ship in ships {
            let forward = Vector2::new(-ship.rotation.sin(), ship.rotation.cos());
            let right = Vector2::new(forward.y, -forward.x);
            let pos = ship.position;
            let rotation = ship.rotation;

            let engine_plumes: [(Vector2, f32, f32); 5] = [
                (
                    forward * 0.6 + right * 0.7,
                    0.0,
                    Vector2::dot(&forward, &ship.thrust).max(0.0) * 0.5,
                ),
                (
                    forward * 0.6 + right * -0.7,
                    0.0,
                    Vector2::dot(&forward, &ship.thrust).max(0.0) * 0.5,
                ),
                (
                    forward * -1.1,
                    std::f32::consts::PI,
                    Vector2::dot(&-forward, &ship.thrust).max(0.0),
                ),
                (
                    forward * -0.25 + right * 1.5,
                    std::f32::consts::PI * -0.5,
                    Vector2::dot(&right, &ship.thrust).max(0.0),
                ),
                (
                    forward * -0.25 + right * -1.5,
                    std::f32::consts::PI * 0.5,
                    Vector2::dot(&-right, &ship.thrust).max(0.0),
                ),
            ];

            for (plume_offset, plume_rotation, plume_intensity) in engine_plumes.iter() {
                let half_w = 0.15 * SHIP_RADIUS / self.engine_plume_image.width() as f32;
                let half_h = 0.3 * SHIP_RADIUS / self.engine_plume_image.height() as f32;
                let p = graphics::DrawParam::new()
                    .dest(pos - Vector2::new(0.5, 0.5) + plume_offset * SHIP_RADIUS * 0.8)
                    .scale(Vector2::new(half_w * 2.0, half_h * 2.0) * 1.3)
                    .offset(Point2::new(0.5, 0.5))
                    .rotation(rotation + plume_rotation)
                    .color(graphics::Color::new(1.0, 1.0, 1.0, *plume_intensity));
                graphics::draw(ctx, &self.engine_plume_image, p).unwrap();
            }

            {
                let image = if ship.ship_type == DrawShipType::Player {
                    &self.player_image
                } else {
                    &self.enemy_image
                };

                let half_w = SHIP_RADIUS / image.width() as f32;
                let half_h = SHIP_RADIUS / image.height() as f32;
                let p = graphics::DrawParam::new()
                    .dest(pos - Vector2::new(0.5, 0.5))
                    .scale(Vector2::new(half_w * 2.0, half_h * 2.0) * 1.3) // Expand to account for padding in the image
                    .offset(Point2::new(0.5, 0.5))
                    .rotation(rotation);
                graphics::draw(ctx, image, p).unwrap();
            }
        }
    }
}
