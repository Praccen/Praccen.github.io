/*!
 * # Embark Studios Code Test
 *
 * Welcome to the *Embark Studios Code Test*!
 *
 * Your mission is to create an *Asteroids*-like game in the **Rust** language, using the **code-test-lib crate**
 * and whatever other resources you deem necessary. Besides the player's space ship, the game should contain one or more
 * AI-controlled ships fighting the player (and each other). You will need to implement parts of the core game logic
 * as well as simple physics to resolve object interactions and raycasts.
 *
 * We designed this assignment so that you could show off your engineering skills, creativity, algorithm design, and illustrate
 * what *you* think is good code. Parts of the test are intentionally constrained, with the goal of directing your efforts towards
 * areas that we believe will spark interesting conversations during your interview.
 * That's right, it's not just about *seeing* your code, we would love a follow-up discussion too!
 *
 * In order not to take too much of your time, we provide a few building blocks; you don't have to implement absolutely everything
 * from scratch. At the same time, we tried not to impose too much structure over the helper traits and functions - it's up to you
 * to come up with sensible data organization. If can conjure with a fun/weird/challenging game on top that,
 * it will certainly be a plus!
 *
 * ## Rust
 *
 * First of all, if you have never programmed in Rust, do not despair! Rust is a very newcomer-friendly language,
 * with a great ecosystem, a lovable community, and learning resources for all sorts of backgrounds and knowledge levels.
 * This should be enough to get you started:
 *
 * * [rustup.rs - The Rust toolchain installer](https://rustup.rs/)
 * * [The Book - Rust Programming Language](https://doc.rust-lang.org/book/)
 * * [A curated list of Rust code and resources](https://github.com/rust-unofficial/awesome-rust#resources)
 * * [RLS-based plugin for VSCode](https://github.com/rust-lang/rls-vscode)
 *
 * ## Where to start
 *
 * This crate provides a number of utilities and wrappers to get you off the ground running. For example, we take care
 * of the window creation, keyboard/mouse input, and some basic rendering tasks. It's all built on top of the [ggez](http://ggez.rs/)
 * library, and includes [nalgebra](https://nalgebra.org/) for points, vectors, matrices, etc. You may add other libraries via Cargo,
 * but doing so is entirely optional; it is possible to create a compelling implementation with just the provided utilities.
 * Please note that *ggez* relies on *SDL2* which comes with
 * [platform-specific build instructions](https://github.com/ggez/ggez/blob/master/docs/BuildingForEveryPlatform.md).
 *
 * In addition to this crate, you have been provided with a bare-bones implementation of a game. Feel free to use it as a basis
 * for your own version! In its source code you will also find some tips for how to proceed.
 *
 * In order to try the example implementation, simply use `cargo run --bin example`. You should be presented
 * with a single player-controlled space ship. It moves around, but cannot shoot just yet.
 *
 * Should you choose not to use the provided example game, please bear in mind that we would still like you to implement
 * behaviors using the provided [`ShipBehavior`](behavior/trait.ShipBehavior.html) trait, and simulate ship motions via
 * [`sim::simulate_ship`](sim/fn.simulate_ship.html).
 *
 * We hope that you will find this a fun experience, and we are eager to hear your feedback! Good luck!
 */

/// Traits used to implement custom ship behaviors, helpers for bulk behavior processing.
pub mod behavior;

/// Ray casting needed by behaviors. Also useful for projectiles. Needs an implementation!
pub mod raycast;

/// Wrapper over game logic, opening the window, etc.
pub mod game;

/// Graphics utilities for drawing ships, asteroids, projectiles. Also coordinate transformations.
pub mod gfx;

/// Drop-in player ship behavior. Please feel free to use it in your game!
pub mod player;

/// Public imports of modules useful in writing your game.
pub mod prelude;

/// Simulation of ship reactions to player/AI inputs. Please use it in your implementation.
pub mod sim;

/// Radius of the bounding circle of player and enemy ships.
pub const SHIP_RADIUS: f32 = 0.07;

/// Alias of nalgebra type
pub type Point2 = ggez::nalgebra::Point2<f32>;

/// Alias of nalgebra type
pub type Vector2 = ggez::nalgebra::Vector2<f32>;
