use super::{behavior::*, Point2, Vector2};

use std::sync::mpsc::Receiver;

/// Mouse cursor position, either in pixel or in world coordinates.
#[derive(Clone, Copy)]
pub enum CursorPos {
    ScreenPixels(Point2),
    WorldSpace(Point2),
}

/// All the possible player interactions.
#[derive(Clone, Copy)]
pub struct PlayerInput {
    /// Mouse cursor position.
    pub cursor_pos: CursorPos,

    /// Either the 'Up' arrow or 'W'.
    pub up: bool,

    /// Either the 'Down' arrow or 'S'.
    pub down: bool,

    /// Either the 'Left' arrow or 'A'.
    pub left: bool,

    /// Either the 'Right' arrow or 'D'.
    pub right: bool,

    /// Any mouse button.
    pub shoot: bool,

    /// Space
    pub special: bool,
}

impl PlayerInput {
    pub fn new() -> PlayerInput {
        PlayerInput {
            cursor_pos: CursorPos::ScreenPixels(Point2::origin()),
            up: false,
            down: false,
            left: false,
            right: false,
            shoot: false,
            special: false,
        }
    }
}

impl Default for PlayerInput {
    fn default() -> Self {
        PlayerInput::new()
    }
}

/// Calculate the shortest distance between two angles expressed in radians.
///
/// Based on https://gist.github.com/shaunlebron/8832585
pub fn angle_shortest_dist(a0: f32, a1: f32) -> f32 {
    let max = std::f32::consts::PI * 2.0;
    let da = (a1 - a0) % max;
    2.0 * da % max - da
}

/// Calculate torque for rotating the player's ship towards a given direction.
///
/// Inspired by proportional-derivative controllers, but approximated with just the current spin
/// instead of error derivatives. Uses arbitrary constants tuned for player control.
pub fn calculate_player_ship_torque_for_aim(aim: Vector2, rotation: f32, spin: f32) -> f32 {
    let target_rot = if aim.x == 0.0 && aim.y == 0.0 {
        rotation
    } else {
        (-aim.x).atan2(aim.y)
    };

    let angle_diff = angle_shortest_dist(rotation, target_rot);

    angle_diff * 100.0 - spin * 15.0
}

/// A royalty-free player ship behavior! Supports movement, aiming, and shooting.
///
/// Send inputs using an `std::sync::mpsc::SyncSender` (imported for your convenience
/// in the [`prelude`](../prelude/index.html)).
pub struct PlayerShipBehavior {
    input_channel: Receiver<PlayerInput>,
}

impl PlayerShipBehavior {
    pub fn new(input_channel: Receiver<PlayerInput>) -> Self {
        Self { input_channel }
    }
}

impl ShipBehavior for PlayerShipBehavior {
    fn behave(
        &mut self,
        ship: &BehaviorShipInfo,
        _game: &BehaviorGameInfo,
        _dt: f32,
        api: &mut dyn ShipBehaviorApi,
    ) {
        let input = self.input_channel.recv().unwrap();

        let mut thrust = Vector2::new(
            input.left as i32 as f32 - input.right as i32 as f32,
            input.down as i32 as f32 - input.up as i32 as f32,
        );

        // Decay velocity
        thrust += ship.velocity * 0.3;
        api.set_thrust(thrust);

        let cursor_pos = if let CursorPos::WorldSpace(pos) = input.cursor_pos {
            pos
        } else {
            panic!(
                "Translate screen-space mouse coordinates to world-space using gfx::ScreenToWorld"
            );
        };

        api.set_torque(calculate_player_ship_torque_for_aim(
            cursor_pos - ship.position,
            ship.rotation,
            ship.spin,
        ));

        if input.shoot {
            api.shoot();
        }
    }
}
