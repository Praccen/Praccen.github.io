use super::{Point2, Vector2};

/// Payload for an individual raycast.
#[derive(Clone, Copy)]
pub struct Raycast {
    /// Starting point of the raycast.
    pub origin: Point2,

    /// Direction; does not need to be normalized. All distance (`t`) values considered
    /// are multiplicative over this, meaning that a raycast in the direction `[1, 0]` returning `t = 2`
    /// must be equivalent to a raycast in the direction `[2, 0]` returning `t = 1`.
    pub direction: Vector2,

    /// The raycast should ignore anything before this `t`.
    pub t_min: f32,

    /// The raycast should ignore anything after this `t`.
    pub t_max: f32,
}

/// Ray hit result.
#[derive(Clone, Copy)]
pub struct RayHit {
    /// What did we hit?
    pub kind: RayHitKind,

    /// How far was it?
    pub t: f32,
}

/// Specifies which object was hit by a ray.
#[derive(Clone, Copy, PartialEq)]
pub enum RayHitKind {
    Ship,
    Asteroid,
}

/// Implement this trait in order for ship behaviors to be able to process visibility raycasts.
pub trait RaycastProcessor {
    /// Given a slice of `rays`, perform ray-scene intersection, and write the results
    /// to the pre-allocated `hits` slice provided.
    fn process_raycasts(&self, rays: &[Raycast], hits: &mut [Option<RayHit>]);
}
