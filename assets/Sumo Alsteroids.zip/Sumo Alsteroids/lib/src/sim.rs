use super::{behavior::ShipControls, Point2, Vector2};

const SHIP_MAX_FORCE: f32 = 3.6;
const SHIP_MAX_TORQUE: f32 = 120.0;

fn clamp_norm_to_one(v: Vector2) -> Vector2 {
    let n = v.norm();
    if n > 1.0 {
        v / n
    } else {
        v
    }
}

/// Simulate the effect of ship controls in a time span.
///
/// # Arguments
/// * `controls` - Part of [`ShipAction`](../behavior/struct.ShipAction.html),
/// calculated by [`ShipBehaviorProcessor`](../behavior/struct.ShipBehaviorProcessor.html).
/// * `dt` - Delta time for this simulation period, in seconds.
/// * `position` - Current ship position. Will be mutated in-place to update according to the simulation.
/// * `velocity` - Current ship velocity. Ditto.
/// * `rotation` - Rotation in radians. Counter-clockwise, zero degrees means pointing up. Ditto.
pub fn simulate_ship(
    controls: ShipControls,
    dt: f32,
    position: &mut Point2,
    velocity: &mut Vector2,
    rotation: &mut f32,
    spin: &mut f32,
) {
    *velocity += clamp_norm_to_one(controls.thrust) * -SHIP_MAX_FORCE * dt;
    *position += *velocity * dt;
    *spin += controls.torque.max(-SHIP_MAX_TORQUE).min(SHIP_MAX_TORQUE) * dt;
    *rotation += *spin * dt;
}
